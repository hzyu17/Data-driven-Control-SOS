% SOSTOOLS -- Sum of Squares Toolbox, internal files
% Version 3.03 
% 1st April 2018.